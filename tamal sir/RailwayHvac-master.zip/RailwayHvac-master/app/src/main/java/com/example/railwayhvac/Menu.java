package com.example.railwayhvac;

public class Menu {

    int icon;
    String text;

   public Menu(int icon,String text){

       this.icon=icon;
       this.text=text;


    }


    public int getIcon() {
        return icon;
    }

    public String getText() {
        return text;
    }
}
