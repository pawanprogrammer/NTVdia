package com.kalkinemedia.Helper;

public class Configure {
    public static final String Youtube_Key="AIzaSyAMJWAFATpxPFsoTFAjSCgVrGMxygOr6PU";
}
